# ✦ Celeste Oracle
### AI-Powered Astrology App — by अ TechnicalMonk

---

## 🚀 Deploy to Netlify (Step-by-Step)

### Step 1 — Get an Anthropic API Key
1. Go to https://console.anthropic.com
2. Sign up / log in
3. Go to **API Keys** → click **Create Key**
4. Copy the key (starts with `sk-ant-...`) — save it safely!

---

### Step 2 — Upload to GitHub
1. Go to https://github.com and create a **New Repository** (name it `celeste-oracle`)
2. Extract this ZIP file on your computer
3. Open a terminal in the extracted folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/celeste-oracle.git
git push -u origin main
```

---

### Step 3 — Deploy on Netlify
1. Go to https://netlify.com and log in (or sign up free)
2. Click **"Add new site"** → **"Import an existing project"**
3. Choose **GitHub** → select your `celeste-oracle` repo
4. Build settings are auto-detected from `netlify.toml`:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Click **"Deploy site"**

---

### Step 4 — Add Your API Key (IMPORTANT!)
1. In Netlify dashboard → go to your site → **Site configuration**
2. Click **Environment variables** → **Add a variable**
3. Set:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-...` (your key from Step 1)
4. Click **Save**
5. Go to **Deploys** → click **"Trigger deploy"** → **"Deploy site"**

---

### Step 5 — Share Your App! 🎉
Your app is live at: `https://your-site-name.netlify.app`

You can set a custom domain in Netlify → **Domain management**.

---

## 🗂 Project Structure

```
celeste-oracle/
├── index.html                  # HTML entry point
├── netlify.toml                # Netlify build & function config
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx                # React entry point
│   └── App.jsx                 # Main app (UI + logic)
└── netlify/
    └── functions/
        └── chat.js             # Serverless proxy (keeps API key secret)
```

---

## 🔒 Security
Your Anthropic API key is stored as an environment variable in Netlify and **never exposed** to the browser. All AI requests go through the `netlify/functions/chat.js` serverless function.

---

## 🛠 Local Development
```bash
npm install
npm run dev
```
For local dev with the Netlify function, install the Netlify CLI:
```bash
npm install -g netlify-cli
netlify dev
```
Then add your API key to a `.env` file:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```
